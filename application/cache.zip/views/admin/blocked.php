<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- 404 Error Text -->
    <div class="text-center">
        <div class="error mx-auto" data-text="403">403</div>
        <p class="lead text-gray-800 mb-5">Access Forbiden</p>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->