<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
        <a href="<?= base_url() ?>admin/teknisi/sudahKonfirmasi" class="btn btn-primary float-left"><i class="fas fa-fw fa-chevron-left"></i> Kembali</a>
    </div>
    <div class="row mt-2">
        <div class="col-lg-2">
            <img src="<?= base_url() ?>image/profile/default.png" class="rounded float-left img-fluid">
        </div>
        <div class="col-lg-5">
            <div class="btn-group float-right" role="group" aria-label="Basic example">
                <a href="<?= base_url() ?>admin/teknisi/statusUpdate/<?= $transaksi['id_transaksi']  ?>/<?= print time() ?>/<?= $transaksi['status_pembayaran'] ?>/1" name="selesaibtn" id="selesaibtn" class="btn btn-dark kerjakanbtn" data-toggle="tooltip" title="Kerjakan"><i class="far fa-fw fa-check-circle"></i> Kerjakan</a>
                <a href="<?= base_url() ?>admin/teknisi/statusUpdate/<?= $transaksi['id_transaksi']  ?>/<?= print time() ?>/<?= $transaksi['status_pembayaran'] ?>/0" name="batalbtn" id="batalbtn" class="btn btn-dark batalbtn" data-toggle="tooltip" title="Batal"><i class="far fa-fw fa-times-circle"></i> Batal</a>
            </div>
            <h1 class="text-gray-800"><?= $transaksi['nama_pelanggan'] ?></h1>
            <table class="table table-borderless table-responsive">
                <tr>
                    <th>No Handphone</td>
                    <td> 0<?= $transaksi['no_hp'] ?></td>
                </tr>
                <tr>
                    <th>Alamat</td>
                    <td><?= $transaksi['alamat'] ?></td>
                </tr>
            </table>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-lg-12">
            <h3>Detail Kerusakan</h3>
            <table class="table table-responsive">
                <tr>
                    <th>Nama&nbspDevice</th>
                    <th>Kerusakan</th>
                    <th>Harga</th>
                    <th>Banyaknya</th>
                    <th>Total&nbspHarga</th>
                </tr>
                <?php foreach ($detail as $dtl) : ?>
                    <tr>
                        <td><?= $transaksi['product'] . $transaksi['platform'] ?></td>
                        <td><?= $dtl['nama_barang'] ?> </td>
                        <td><?= rupiah($dtl['harga']) ?></td>
                        <td><?= $dtl['quantity'] ?></td>
                        <td><?= rupiah($dtl['total_harga']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->