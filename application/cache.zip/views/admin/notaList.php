<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo $tittle ?></h1>
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <span class="breadcrumb-item">Nota Belum Diambil</a></span>
                    </h6>
                </div>
                <div class="card-body">
                    <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>

                    <?= $this->session->flashdata('message'); ?>
                    <!-- <a class="btn btn-primary mb-3" href="<?= base_url() ?>admin/gudang/addNewStuff">Tambahkan Barang</a>
                    <a class="btn btn-primary mb-3" href="<?= base_url() ?>admin/gudang/addStock">Add Stock</a> -->

                    <!-- <span class="float-right font-weight-bold">Total Aset = <?php echo rupiah($total) ?></span> -->
                    <!-- DataTales Product -->
                    <div style="overflow-x:auto;">
                        <table class="table table-bordered dataTable" id="dataTableProduct" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>ID&nbspNota</th>
                                    <th>ID&nbspMember</th>
                                    <th>Nama&nbspPelanggan</th>
                                    <th>Nomor&nbspTelfon</th>
                                    <th>Tanggal&nbspMasuk</th>
                                    <th>Tanggal&nbspDiambil</th>
                                    <th>Device</th>
                                    <th>Item</th>
                                    <th>Total</th>
                                    <th>Diskon</th>
                                    <th>Grand&nbspTotal</th>
                                    <th>DP</th>
                                    <th>Status&nbspPembayaran</th>
                                    <th>Status&nbspPengerjaan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($nota as $nt) : ?>

                                    <tr>
                                        <td>
                                            <div class="btn-group" role="group" aria-label="Basic example">
                                                <?php if ($nt['status_pembayaran'] < 99 || $nt['stasus_pengerjaan']) : ?>
                                                    <a class="btn btn-dark btn-sm" href="<?= base_url() ?>admin/kasir/Bayar/<?= $nt['id_transaksi'] ?>" data-toggle="tooltip" title="Bayar"><i class="fas fa-fw fa-money-bill-wave"></i></a>
                                                <?php else : ?>
                                                <?php endif ?>
                                                <a class="btn btn-dark btn-sm" href="<?= base_url() ?>admin/kasir/cetakNota/<?= $nt['id_transaksi'] ?>" target="_blank" data-toggle="tooltip" title="Print"><i class="fas fa-fw fa-print"></i></a>
                                            </div>
                                        </td>
                                        <td><?= $nt['id_transaksi'] ?></td>
                                        <td><?= $nt['id_pelanggan'] ?></td>
                                        <td><?= $nt['nama_pelanggan'] ?></td>
                                        <td><?php echo '+62' . $nt['no_hp'] ?></td>
                                        <td>
                                            <?php $date = date('Y-m-d', $nt['tanggal_taransaksi']);
                                            echo longdate_indo($date);
                                            ?>
                                        </td>
                                        <?php if ($nt['tanggal_diambil'] != 0) : ?>
                                            <td>
                                                <?php $date = date('Y-m-d', $nt['tanggal_diambil']);
                                                echo longdate_indo($date);
                                                ?>
                                            </td>
                                        <?php else : ?>
                                            <td>
                                                Belum&nbspDiambil
                                            </td>
                                        <?php endif; ?>
                                        <td><?php echo $nt['product'] . '&nbsp' . $nt['platform'] ?></td>
                                        <td><?= $nt['total_barang'] ?></td>
                                        <td><?= rupiah($nt['total']) ?></td>
                                        <?php
                                        if ($nt['disc_status'] == 0) {
                                            $diskon = rupiah($nt['diskon']);
                                        } else {
                                            $diskon = $nt['diskon'] . '%';
                                        }
                                        ?>
                                        <td><?= $diskon ?></td>
                                        <td><?= rupiah($nt['grand_total']) ?></td>
                                        <?php $nominal_kembalian = $nt['change_nominal'];
                                        $grand_total = $nt['grand_total'];
                                        $nominal = $grand_total + ($nominal_kembalian);


                                        if ($nominal > 0 && $nominal < $grand_total) {
                                            echo '<td>' . rupiah($nominal) . '</td>';
                                            //DP

                                        } elseif ($nominal == 0) {
                                            echo '<td> Tidak&nbspDP </td>';
                                            //Tidak dp
                                        } elseif ($nominal <= $grand_total) {
                                            echo '<td> Tidak&nbspDP </td>';
                                        } elseif ($nominal > $grand_total) {
                                            echo '<td> Tidak&nbspDP </td>';
                                        }
                                        ?>

                                        <!-- <td><?= $dp ?></td> -->
                                        <td><?= $nt['sPembayaran'] ?></td>
                                        <td><?= $nt['sPengerjaan'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->