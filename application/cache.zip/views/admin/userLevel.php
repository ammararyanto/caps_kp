<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800"><?php echo $tittle ?></h1>


    <div class="row">
        <div class="col-lg-12">
            <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>

            <?= $this->session->flashdata('message'); ?>

            <a href="<?= base_url() ?>admin/admin/addUser" class="btn btn-primary mb-3">Add New Employee</a>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Jabatan</th>
                        <th scope="col">Tindakan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($userLevel as $u) : ?>
                    <tr>
                        <th scope="row"><?= $i; ?></th>
                        <th>
                            <?php
                                $tmp = explode(" ", $u['name']);
                                echo $u['name'] = implode("&nbsp;", $tmp);
                                ?>
                        </th>
                        <th><?= $u['email'] ?></th>
                        <th><?= $u['role'] ?></th>
                        <th>
                            <a href="<?= base_url('admin/admin/userLevelChange/') . $u['id'] ?>" class="btn btn-primary btn-sm">Ubah</a>
                            <a href="<?= base_url('admin/admin/userLevelDelete/') . $u['id'] ?>" class="btn btn-danger btn-sm delete-btn">Hapus</a>
                        </th>
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>

        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->