<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <a href="<?= base_url() ?>admin/teknisi/teknisiCek" class="text-xs font-weight-bold text-info text-uppercase mb-1">Perlu di Cek</a>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <a href="<?= base_url() ?>admin/teknisi/teknisiCek" class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?= $belumDicek ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <a href="<?= base_url() ?>admin/teknisi/teknisiCek"> <i class="fas fa-clipboard-list fa-2x text-gray-300"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <a href="<?= base_url() ?>admin/teknisi/menungguKonfirmasi" class="text-xs font-weight-bold text-info text-uppercase mb-1">Menunggu Konfirmasi</a>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <a href="<?= base_url() ?>admin/teknisi/menungguKonfirmasi" class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?= $menungguKonfirmasi ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <a href="<?= base_url() ?>admin/teknisi/menungguKonfirmasi"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <a href="<?= base_url() ?>admin/teknisi/sudahKonfirmasi" class="text-xs font-weight-bold text-info text-uppercase mb-1">Sudah dikonfirmasi</a>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <a href="<?= base_url() ?>admin/teknisi/sudahKonfirmasi" class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?= $sudahKonfirmasi ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <a href="<?= base_url() ?>admin/teknisi/sudahKonfirmasi"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <a href="<?= base_url() ?>admin/teknisi/daftarServisan" class="text-xs font-weight-bold text-info text-uppercase mb-1">Daftar Antrian Servis</a>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <a href="<?= base_url() ?>admin/teknisi/daftarServisan" class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?= $daftarServisan ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <a href="<?= base_url() ?>admin/teknisi/daftarServisan"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Heading -->


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->