<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Candra Apple Solution <?= date('Y') ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->
</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="<?= base_url() ?>auth/logout">Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="<?= base_url() ?>assets/dist_admin/jquery/jquery.min.js"></script>
<script src="<?= base_url() ?>assets/dist_admin/bootstrap/js/bootstrap.bundle.min.js"></script>


<!-- Core plugin JavaScript-->
<script src="<?= base_url() ?>assets/dist_admin/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url() ?>assets/js_admin/sb-admin-2.min.js"></script>

<!-- Sweet Alert -->
<script src="<?= base_url(); ?>assets/dist_admin/sweetalert2/sweetalert2.all.min.js"></script>
<script src="<?= base_url(); ?>assets/dist_admin/sweetalert2/mysweetalert.js"></script>

<!-- Data Table -->
<script src="<?= base_url() ?>assets/dist_admin/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/dist_admin/datatables/dataTables.bootstrap4.min.js"></script>

<!-- ck editor -->
<script src="<?= base_url() ?>assets/dist_admin/ckeditor/ckeditor.js" type="text/javascript"></script>
<!-- Tag suggestion -->
<script type="text/javascript" src="<?= base_url() ?>assets/js_admin/jquery.amsify.suggestags.js"></script>

<!-- search js kasir -->
<script>
    $(this).ready(function() {
        load_data();

        function load_data(query) {
            $.ajax({
                url: "<?= base_url() ?>admin/kasir/fetch",
                method: "POST",
                data: {
                    query: query
                },
                success: function(data) {
                    $('#result').html(data);
                }
            })
        }

        $('.search').keyup(function() {
            var search = $(this).val();
            if (search != '') {
                load_data(search);
            } else {
                load_data();
            }
        })
    })
</script>
<!-- search js teknisi -->
<script>
    $(this).ready(function() {
        load_data();

        function load_data(query) {
            $.ajax({
                url: "<?= base_url() ?>admin/teknisi/fetch",
                method: "POST",
                data: {
                    query: query
                },
                success: function(data) {
                    $('#resultTeknisi').html(data);
                }
            })
        }

        $('.searchTeknisi').keyup(function() {
            var search = $(this).val();
            if (search != '') {
                load_data(search);
            } else {
                load_data();
            }
        })
    })
</script>

<!-- cart js -->
<script>
    function tambahKeranjang(nmbr) {
        var product_id = $('.btn_add' + nmbr).data("productid");
        var product_name = $('.btn_add' + nmbr).data("productname");
        var product_price = $('.btn_add' + nmbr).data("price");
        var qty = $('#' + product_id).val();
        if (qty != '' && qty >= 0) {
            $.ajax({
                url: "<?php echo base_url(); ?>admin/kasir/tambahKeranjang",
                method: "POST",
                data: {
                    product_id: product_id,
                    product_name: product_name,
                    product_price: product_price,
                    qty: qty
                },
                success: function(data) {
                    alert("Produk ditambahkan");
                    $('#cart_details').html(data);
                }
            });
        } else {
            alert("Please enter qty");
        }
    }

    $(document).ready(function() {

        $('#cart_details').load("<?php echo base_url() ?>admin/kasir/muatKeranjang");

        $(document).on('click', '.hapus_item', function() {
            var row_id = $(this).attr("id");
            if (confirm("Yakin akan menghapus barang?")) {
                $.ajax({
                    url: "<?php echo base_url() ?>admin/kasir/hapusItem",
                    method: "POST",
                    data: {
                        row_id: row_id
                    },
                    success: function(data) {
                        alert("Produk dihapus dari keranjang");
                        $('#cart_details').html(data);
                    }
                });
            } else {
                return false;
            }
        });
    });


    // diskon

    $(document).ready(function() {
        $('.diskon').keyup(function() {
                var diskon = $(this).val();
                $('.diskonnom').val(diskon);
            })
            .keyup();
    })
    $(document).ready(function() {
        $('#nominal').on('click', function() {
            var total = $('.total_trs').val();
            var potongan = $('.diskonnom').val();
            var totalpdiskon = total - potongan;
            $('.grand_total').text(totalpdiskon);
            $('.totalpdiskon').val(totalpdiskon);
        })

        $('#prosentase').on('click', function() {
            var total = $('.total_trs').val();
            var diskon = $('.diskonnom').val();
            var potongan = diskon * 1 / 100;
            var jumlahpotongan = total * potongan;
            var totalpdiskon = total - jumlahpotongan;
            $('.grand_total').text(totalpdiskon);
            $('.totalpdiskon').val(totalpdiskon);
        })
    })

    // kembalian

    $(document).ready(function() {
        $('.uang_cash').keyup(function() {
                var totalpdiskon = $('.totalpdiskon').val();
                var cash = $(this).val();
                var kembalian = cash - totalpdiskon;
                $('.kembalian').text(kembalian);
                $('.kembalian').val(kembalian);
            })
            .keyup();
    });
</script>
<script>
    $(document).ready(function() {

        $('#cart_detailsubh').load("<?php echo base_url() ?>admin/kasir/ubahBayar/<?= $transaksi['id_transaksi'] ?>");

    });
</script>

<!-- cart js teknisi -->
<script>
    function tambahKerusakan(nmbr) {
        var product_id = $('.btn_add' + nmbr).data("productid");
        var product_name = $('.btn_add' + nmbr).data("productname");
        var product_price = $('.btn_add' + nmbr).data("price");
        var qty = $('#' + product_id).val();
        if (qty != '' && qty >= 0) {
            $.ajax({
                url: "<?php echo base_url(); ?>admin/teknisi/tambahKerusakan/<?= $transaksi['id_transaksi'] ?>",
                method: "POST",
                data: {
                    product_id: product_id,
                    product_name: product_name,
                    product_price: product_price,
                    qty: qty
                },
                success: function(data) {
                    alert("Produk ditambahkan");
                    $('#cart_detailstek').html(data);
                }
            });
        } else {
            alert("Please enter qty");
        }
    }

    $(document).ready(function() {

        $('#cart_detailstek').load("<?php echo base_url() ?>admin/teknisi/muatKeranjang/<?= $transaksi['id_transaksi'] ?>");

        $(document).on('click', '.hapus_itemtek', function() {
            var row_id = $(this).attr("id");
            if (confirm("Yakin akan menghapus barang?")) {
                $.ajax({
                    url: "<?php echo base_url() ?>admin/teknisi/hapusItem/<?= $transaksi['id_transaksi'] ?>",
                    method: "POST",
                    data: {
                        row_id: row_id
                    },
                    success: function(data) {
                        alert("Produk dihapus dari keranjang");
                        $('#cart_detailstek').html(data);
                    }
                });
            } else {
                return false;
            }
        });
    });

    // diskon

    $(document).ready(function() {
        $('.diskontek').keyup(function() {
                var diskon = $(this).val();
                $('.diskonnomtek').val(diskon);
            })
            .keyup();
    })
    $(document).ready(function() {
        $('#nominaltek').on('click', function() {
            var total = $('.total_trstek').val();
            var potongan = $('.diskonnomtek').val();
            var totalpdiskon = total - potongan;
            $('.grand_totaltek').text(totalpdiskon);
            $('.totalpdiskontek').val(totalpdiskon);
        })

        $('#prosentasetek').on('click', function() {
            var total = $('.total_trstek').val();
            var diskon = $('.diskonnomtek').val();
            var potongan = diskon * 1 / 100;
            var jumlahpotongan = total * potongan;
            var totalpdiskon = total - jumlahpotongan;
            $('.grand_totaltek').text(totalpdiskon);
            $('.totalpdiskontek').val(totalpdiskon);
        })
    })

    // kembalian

    $(document).ready(function() {
        $('.uang_cash').keyup(function() {
                var totalpdiskon = $('.totalpdiskon').val();
                var cash = $(this).val();
                var kembalian = cash - totalpdiskon;
                $('.kembalian').text(kembalian);
                $('.kembalian').val(kembalian);
            })
            .keyup();
    });
</script>

<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });

    $('.form-check-input').on('click', function() {

        const menuId = $(this).data('menu');
        const roleId = $(this).data('role');

        $.ajax({
            url: "<?= base_url('admin/admin/changeAccess') ?>",
            type: 'post',
            data: {
                menuId: menuId,
                roleId: roleId
            },
            success: function() {
                document.location.href = "<?= base_url('admin/admin/roleaccess/') ?>" + roleId;
            }
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#dataTableProduct').DataTable();
    });
    $('input[name="tag"]').amsifySuggestags();
</script>

<script>
    $(document).ready(function() {

        $("#product_id").change(function() { // Ketika user mengganti atau memilih data
            $("#platform_id").hide(); // Sembunyikan dulu tipe devicenya

            $.ajax({
                type: "POST", // Method pengiriman data bisa dengan GET atau POST
                url: "<?php echo base_url(); ?>admin/kasir/platformSelect", // Isi dengan url/path file php yang dituju
                data: {
                    product_id: $("#product_id").val()
                }, // data yang akan dikirim ke file yang dituju
                dataType: "json",
                beforeSend: function(e) {
                    if (e && e.overrideMimeType) {
                        e.overrideMimeType("application/json;charset=UTF-8");
                    }
                },
                success: function(response) { // Ketika proses pengiriman berhasil
                    // Sembunyikan loadingnya $("#loading").hide();
                    // set isi dari combobox kota
                    // lalu munculkan kembali combobox kotanya
                    $("#platform_id").html(response.platform_id).show();
                },
                error: function(xhr, ajaxOptions, thrownError) { // Ketika ada error
                    alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
                }
            });
        });
    });
</script>

</body>

</html>