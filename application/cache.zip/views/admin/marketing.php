<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <a href="<?= base_url() ?>admin/marketing/harusKonfirmasi" class="text-xs font-weight-bold text-info text-uppercase mb-1">Harus Dikonfirmasi</a>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <a href="<?= base_url() ?>admin/marketing/harusKonfirmasi" class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?= $menungguKonfirmasi ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <a href="<?= base_url() ?>admin/marketing/harusKonfirmasi"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <a href="<?= base_url() ?>admin/marketing/belumDiambil" class="text-xs font-weight-bold text-info text-uppercase mb-1">Belum Diambil</a>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <a href="<?= base_url() ?>admin/marketing/belumDiambil" class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?= $belumDiambil ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <a href="<?= base_url() ?>admin/marketing/belumDiambil"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Heading -->


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->