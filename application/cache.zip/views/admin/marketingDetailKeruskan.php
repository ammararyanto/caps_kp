<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
        <?php if ($transaksi['stasus_pengerjaan'] < 5) : ?>
            <a href="<?= base_url() ?>admin/marketing/harusKonfirmasi" class="btn btn-primary float-left"><i class="fas fa-fw fa-chevron-left"></i> Kembali</a>
        <?php else : ?>
            <a href="<?= base_url() ?>admin/marketing/belumDiambil" class="btn btn-primary float-left"><i class="fas fa-fw fa-chevron-left"></i> Kembali</a>
        <?php endif; ?>
    </div>
    <div class="row mt-2">
        <div class="col-lg-2">
            <img src="<?= base_url() ?>image/profile/default.png" class="rounded float-left img-fluid">
        </div>
        <div class="col-lg-5">
            <?php if ($transaksi['stasus_pengerjaan'] < 5) : ?>
                <a href="<?= base_url() ?>admin/marketing/konfirmasi/<?= $transaksi['id_transaksi'] ?>" class="btn btn-primary float-right konfirmasi">Sudah dikonfirmasi</a>
            <?php else : ?>
            <?php endif; ?>
            <h1 class="text-gray-800"><?= $transaksi['nama_pelanggan'] ?></h1>
            <table class="table table-borderless table-responsive">
                <tr>
                    <th>No Handphone</td>
                    <td> 0<?= $transaksi['no_hp'] ?></td>
                </tr>
                <tr>
                    <th>Alamat</td>
                    <td><?= $transaksi['alamat'] ?></td>
                </tr>
            </table>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-lg-12">
            <h3>Detail Kerusakan</h3>
            <table class="table table-responsive">
                <tr>
                    <th>Nama&nbspDevice</th>
                    <th>Kerusakan</th>
                    <th>Harga</th>
                    <th>Banyaknya</th>
                    <th>Total&nbspHarga</th>
                </tr>
                <?php foreach ($detail as $dtl) : ?>
                    <tr>
                        <td><?= $transaksi['product'] . $transaksi['platform'] ?></td>
                        <td><?= $dtl['nama_barang'] ?> </td>
                        <td><?= rupiah($dtl['harga']) ?></td>
                        <td><?= $dtl['quantity'] ?></td>
                        <td><?= rupiah($dtl['total_harga']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->