<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Nota_model extends CI_Model
{
    public function notaBelumDiambil()
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->where('stasus_pengerjaan !=', 99);
        $this->db->order_by('id_transaksi', 'asc');
        $this->db->join('pelanggan', 'pelanggan.id_member = transaksi.id_pelanggan');
        $this->db->join('status_pembayaran', 'status_pembayaran.id=transaksi.status_pembayaran');
        $this->db->join('status_pengerjaan', 'status_pengerjaan.id=transaksi.stasus_pengerjaan');
        $this->db->join('product_platform', 'product_platform.id = transaksi.platform');
        $this->db->join('product', 'product.id = product_platform.product_id');
        return $query = $this->db->get()->result_array();
    }

    public function notaCancelDone()
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->where('stasus_pengerjaan > ', 4);
        $this->db->where('stasus_pengerjaan < ', 99);
        $this->db->order_by('id_transaksi', 'asc');
        $this->db->join('pelanggan', 'pelanggan.id_member = transaksi.id_pelanggan');
        $this->db->join('status_pembayaran', 'status_pembayaran.id=transaksi.status_pembayaran');
        $this->db->join('status_pengerjaan', 'status_pengerjaan.id=transaksi.stasus_pengerjaan');
        $this->db->join('product_platform', 'product_platform.id = transaksi.platform');
        $this->db->join('product', 'product.id = product_platform.product_id');
        return $query = $this->db->get()->result_array();
    }

    public function notaDiambil()
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->where('stasus_pengerjaan', 99);
        $this->db->order_by('id_transaksi', 'asc');
        $this->db->join('pelanggan', 'pelanggan.id_member = transaksi.id_pelanggan');
        $this->db->join('status_pembayaran', 'status_pembayaran.id=transaksi.status_pembayaran');
        $this->db->join('status_pengerjaan', 'status_pengerjaan.id=transaksi.stasus_pengerjaan');
        $this->db->join('product_platform', 'product_platform.id = transaksi.platform');
        $this->db->join('product', 'product.id = product_platform.product_id');
        return $query = $this->db->get()->result_array();
    }

    public function servisBelumDikerjakan($sPengerjaan)
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->where('stasus_pengerjaan =', $sPengerjaan);
        $this->db->order_by('id_transaksi', 'asc');
        $this->db->join('pelanggan', 'pelanggan.id_member = transaksi.id_pelanggan');
        $this->db->join('status_pengerjaan', 'status_pengerjaan.id=transaksi.stasus_pengerjaan');
        $this->db->join('product_platform', 'product_platform.id = transaksi.platform');
        $this->db->join('product', 'product.id = product_platform.product_id');
        return $query = $this->db->get()->result_array();
    }

    public function servisBelumDikerjakanCount($sPengerjaan)
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->where('stasus_pengerjaan =', $sPengerjaan);
        $this->db->order_by('id_transaksi', 'asc');
        $this->db->join('pelanggan', 'pelanggan.id_member = transaksi.id_pelanggan');
        $this->db->join('status_pengerjaan', 'status_pengerjaan.id=transaksi.stasus_pengerjaan');
        $this->db->join('product_platform', 'product_platform.id = transaksi.platform');
        $this->db->join('product', 'product.id = product_platform.product_id');
        return $this->db->count_all_results();
    }

    public function notaBelumDiambilCount()
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->where('stasus_pengerjaan > ', 4);
        $this->db->where('stasus_pengerjaan < ', 99);
        $this->db->order_by('id_transaksi', 'asc');
        $this->db->join('pelanggan', 'pelanggan.id_member = transaksi.id_pelanggan');
        $this->db->join('status_pengerjaan', 'status_pengerjaan.id=transaksi.stasus_pengerjaan');
        $this->db->join('product_platform', 'product_platform.id = transaksi.platform');
        $this->db->join('product', 'product.id = product_platform.product_id');
        return $this->db->count_all_results();
    }

    public function getNotaByID($id_Transaksi)
    {
        $this->db->select('*');
        $this->db->from('transaksi');
        $this->db->where('id_transaksi', $id_Transaksi);
        $this->db->join('user', 'user.id=transaksi.id_user');
        $this->db->join('pelanggan', 'pelanggan.id_member = transaksi.id_pelanggan');
        $this->db->join('product_platform', 'product_platform.id = transaksi.platform');
        $this->db->join('product', 'product.id = product_platform.product_id');
        return $query = $this->db->get()->row_array();
    }



    public function getDetailTransaksiById($id_Transaksi)
    {
        $this->db->select('*');
        $this->db->from('transaksi_detail');
        $this->db->where('id_transakasi', $id_Transaksi);
        $this->db->join('stok', 'stok.id_barang = transaksi_detail.id_barang');
        return $this->db->get()->result_array();
    }

    public function getDetailTransaksiCount($id_Transaksi)
    {
        $this->db->select('*');
        $this->db->from('transaksi_detail');
        $this->db->where('id_transakasi', $id_Transaksi);
        return $this->db->count_all_results();
    }

    public function deleteDetailTransaksiByID($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('transaksi_detail');
    }

    public function logPengerjaan($id_transaksi,  $datetime, $pembayaran, $sPengerjaan)
    {
        $data = [
            "id" => '',
            "id_transaksi"      => $id_transaksi,
            "datetime"          => $datetime,
            "sPembayaran"       => $pembayaran,
            "sPengerjaan"       => $sPengerjaan
        ];
        $this->db->insert('log_transaksi', $data);

        $transaksi = [
            "stasus_pengerjaan" => $sPengerjaan
        ];

        $this->db->where('id_transaksi', $id_transaksi);
        $this->db->update('transaksi', $transaksi);
    }

    public function cariNota($cari_nota)
    {
        $cari_nota = $this->input->post('cari_nota', true);
        $this->db->where('id_transaksi', $cari_nota);
        $this->db->select('*');
        $this->db->from('log_transaksi');
        $this->db->join('status_pembayaran', 'status_pembayaran.id=log_transaksi.sPembayaran');
        $this->db->join('status_pengerjaan', 'status_pengerjaan.id=log_transaksi.sPengerjaan');
        return $this->db->get()->result_array();
    }
}
