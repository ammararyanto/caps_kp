<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Stok_model extends CI_Model
{
    public function getStok()
    {
        $query = "SELECT `stok`.*,`tipe_penjualan`.*
        FROM `stok` 
        JOIN `tipe_penjualan`
        ON `stok`.`id_tipepenjualan` = `tipe_penjualan`.`id_tipepenjualan`";
        return $this->db->query($query)->result_array();
    }

    public function getStokByID($id_barang)
    {
        $this->db->select('*');
        $this->db->from('stok');
        $this->db->where('id_barang', $id_barang);
        $this->db->join('tipe_penjualan', 'tipe_penjualan.id_tipepenjualan = stok.id_tipepenjualan');
        return $query = $this->db->get()->row_array();
    }

    public function updateStok($id_stok, $stok)
    {
        $data = ["stok_barang" => $stok];
        $this->db->where('id_barang', $id_stok);
        $this->db->update('stok', $data);
    }

    public function getStokByTransaksiPenjualan($query, $tipe_penjualan)
    {
        $this->db->select('*');
        $this->db->where('id_tipepenjualan', $tipe_penjualan);
        $this->db->where('stok_barang > 0');
        $this->db->limit(20);
        $this->db->from('stok');
        if ($query != '') {
            $this->db->like('nama_barang', $query);
            $this->db->or_like('id_barang', $query);
        }
        return $this->db->get();
    }
}
