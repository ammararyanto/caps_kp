<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model

{
    public function getUser()
    {
        $query = "SELECT `user`.*,`user_role`.`role`
        FROM `user` JOIN `user_role`
        WHERE `user`.`role_id` = `user_role`.`id` && `user`.`role_id` != 3 
        ";

        return $this->db->query($query)->result_array();
    }
}
