<?php

class Pdf{
    function __construct()
    {
        include_once ('./assets/dist_admin/fpdf/fpdf.php');
    }
}
