<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Blog extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_log_in();
    }

    public function index()
    {
        $data['tittle'] = "Blog";
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['content'] = $this->db->get('blog')->result_array();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/blog', $data);
        $this->load->view('admin/footer');
    }

    public function service()
    {
        $data['tittle'] = "Blog Service";
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['content'] = $this->db->get('blog')->result_array();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/blog', $data);
        $this->load->view('admin/footer');
    }

    public function add()
    {
        $data['tittle'] = "Add New Article";
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['category'] = $this->db->get('blog_category')->result_array();
        $data['product'] = $this->db->get('product')->result_array();

        $this->form_validation->set_rules('tittle', 'Tittle', 'required|trim');
        $this->form_validation->set_rules('content', 'Content', 'required|trim');
        $this->form_validation->set_rules('tag', 'Tag', 'required|trim');
        $this->form_validation->set_rules('category_id', 'Category', 'required|trim');
        if ($this->input->post('category_id') != 1) {
            $this->form_validation->set_rules('product_id', 'Product', 'required|trim');
        }
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar');
            $this->load->view('admin/topbar', $data);
            $this->load->view('admin/blogAdd', $data);
            $this->load->view('admin/footer');
        } else {
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['upload_path']          = './image/blog/';
                $config['allowed_types']        = 'gif|jpg|png|JPG';
                $config['max_size']             = 6291;

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('picture', $new_image);
                } else {
                    $error = array('error' => $this->upload->display_errors());
                    echo $error;
                }
            } else {
                $data['default'] = "default.jpg";
                $this->db->set('picture', $data['default']);
            }


            $this->db->set('tittle', $this->input->post('tittle'), true);
            $this->db->set('category_id', $this->input->post('category_id'), true);
            $this->db->set('product_id', $this->input->post('product_id'), true);
            $this->db->set('tag', $this->input->post('tag'), true);
            $this->db->set('date_created', time());
            $this->db->set('content', $this->input->post('content'), true);
            $this->db->set('uploader', $this->input->post('uploader'), true);
            $this->db->set('publish', $this->input->post('publish'), true);
            $this->db->insert('blog');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            New article uploaded</div>');
            if ($this->input->post('category_id') != 1) {
                redirect('admin/blog/service');
            } else {
                redirect('admin/blog');
            }
        }
    }
}
