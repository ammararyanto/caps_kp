<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Gudang extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_log_in();
    }

    public function stok()
    {
        $data['tittle'] = "Stok";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $this->load->model('Stok_model');
        $data['stok'] = $this->Stok_model->getStok();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/stok', $data);
        $this->load->view('admin/footer');
    }

    public function addNewStuff()
    {
        $data['tittle'] = "Add New Stuff";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();


        $data['tipe_penjualan'] = $this->db->get('tipe_penjualan')->result_array();

        $this->form_validation->set_rules('id_barang', 'Id Barang', 'required|trim|is_unique[stok.id_barang]');
        $this->form_validation->set_rules('nama_barang', 'Nama Barang', 'required|trim');
        $this->form_validation->set_rules('tipe_penjualan', 'Tipe Penjualan', 'required|trim');
        $this->form_validation->set_rules('harga_beli', 'Harga Beli', 'required|trim');
        $this->form_validation->set_rules('harga_jual', 'Harga Jual', 'required|trim');
        $this->form_validation->set_rules('stok', 'Stok', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar');
            $this->load->view('admin/topbar', $data);
            $this->load->view('admin/stokAddNewStuff', $data);
            $this->load->view('admin/footer');
        } else {

            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['upload_path']          = './image/barang/';
                $config['allowed_types']        = 'gif|jpg|png|JPG';
                $config['max_size']             = 6291;

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('foto', $new_image);
                } else {
                    echo $this->upload->display_errors();
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
            Barang tidak ditambahkan</div>');
                }
            }


            $this->db->set('id_barang', $this->input->post('id_barang'), true);
            $this->db->set('nama_barang', $this->input->post('nama_barang'), true);
            $this->db->set('id_tipepenjualan', $this->input->post('tipe_penjualan'), true);
            $this->db->set('harga_beli', $this->input->post('harga_beli'), true);
            $this->db->set('harga_jual', $this->input->post('harga_jual'), true);
            $this->db->set('stok_barang', $this->input->post('stok'), true);
            $this->db->insert('stok');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            Barang Ditambahkan</div>');
            redirect('admin/gudang/stok');
        }
    }

    public function stuffEdit($id_barang)
    {
        $data['tittle'] = "Edit Stuff";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Stok_model');
        $data['stok'] = $this->Stok_model->getStokByID($id_barang);
        $data['tipe_penjualan'] = $this->db->get('tipe_penjualan')->result_array();

        $this->form_validation->set_rules('nama_barang', 'Nama Barang', 'required|trim');
        $this->form_validation->set_rules('tipe_penjualan', 'Tipe Penjualan', 'required|trim');
        $this->form_validation->set_rules('harga_beli', 'Harga Beli', 'required|trim');
        $this->form_validation->set_rules('harga_jual', 'Harga Jual', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar');
            $this->load->view('admin/topbar', $data);
            $this->load->view('admin/stokEditStuff', $data);
            $this->load->view('admin/footer');
        } else {

            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['upload_path']          = './image/barang/';
                $config['allowed_types']        = 'gif|jpg|png|JPG';
                $config['max_size']             = 6291;

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('foto', $new_image);
                } else {
                    echo $this->upload->display_errors();
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
            Barang tidak ditambahkan</div>');
                }
            }


            $this->db->set('nama_barang', $this->input->post('nama_barang'), true);
            $this->db->set('id_tipepenjualan', $this->input->post('tipe_penjualan'), true);
            $this->db->set('harga_beli', $this->input->post('harga_beli'), true);
            $this->db->set('harga_jual', $this->input->post('harga_jual'), true);
            $this->db->where('id_barang', $id_barang);
            $this->db->update('stok');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            Barang telah dirubah</div>');
            redirect('admin/gudang/stok');
        }
    }

    public function addStock($id_barang)
    {
        $data['tittle'] = "Tambah Stok";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Stok_model');
        $data['stok'] = $this->Stok_model->getStokByID($id_barang);

        $this->form_validation->set_rules('stok', 'Stok', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar');
            $this->load->view('admin/topbar', $data);
            $this->load->view('admin/stokAddStok', $data);
            $this->load->view('admin/footer');
        } else {
            $old_stok = $data['stok']['stok_barang'];
            $add_stok =  $this->input->post('stok', true);
            $update_stok = $old_stok + $add_stok;

            $this->db->set('stok_barang', $update_stok);
            $this->db->where('id_barang', $id_barang);
            $this->db->update('stok');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            Stok telah ditambahkan</div>');
            redirect('admin/gudang/stok');
        }
    }
}
