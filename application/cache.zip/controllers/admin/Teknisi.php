<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Teknisi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_log_in();
    }

    public function index()
    {
        $data['tittle'] = "Teknisi";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Nota_model');
        // $data['nota'] = $this->Nota_model->servisBelumDikerjakan();
        $data['belumDicek'] = $this->Nota_model->servisBelumDikerjakanCount(1);
        $data['menungguKonfirmasi'] = $this->Nota_model->servisBelumDikerjakanCount(2);
        $data['sudahKonfirmasi'] = $this->Nota_model->servisBelumDikerjakanCount(3);
        $data['daftarServisan'] = $this->Nota_model->servisBelumDikerjakanCount(4);

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/teknisi', $data);
        $this->load->view('admin/footer');
    }

    public function teknisiCek()
    {
        $data['tittle'] = "Perlu dicek";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['sPengerjaan'] = 1;
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->servisBelumDikerjakan($data['sPengerjaan']);

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/teknisiBelumDikerjakan', $data);
        $this->load->view('admin/footer');
    }

    public function menungguKonfirmasi()
    {
        $data['tittle'] = "Menunggu Konfirmasi";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['sPengerjaan'] = 2;
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->servisBelumDikerjakan($data['sPengerjaan']);

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/teknisiMenungguKonfirmasi', $data);
        $this->load->view('admin/footer');
    }


    public function sudahKonfirmasi()
    {
        $data['tittle'] = "Sudah dikonfirmasi";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['sPengerjaan'] = 3;
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->servisBelumDikerjakan($data['sPengerjaan']);

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/teknisiSudahKonfirmasi', $data);
        $this->load->view('admin/footer');
    }

    public function lihatDetail($id_kerusakan)
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Nota_model');
        $data['transaksi'] = $this->Nota_model->getNotaByID($id_kerusakan);
        $data['detail'] = $this->Nota_model->getDetailTransaksiById($id_kerusakan);

        $data['tittle'] = "Kerusakan " . $data['transaksi']['nama_pelanggan'];

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/teknisiDetailKeruskan', $data);
        $this->load->view('admin/footer');
    }

    public function daftarServisan()
    {
        $data['tittle'] = "Daftar Antrian Servis";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $data['sPengerjaan'] = 4;
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->servisBelumDikerjakan($data['sPengerjaan']);

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/teknisiBelumDikerjakan', $data);
        $this->load->view('admin/footer');
    }

    public function statusUpdate()
    {

        $this->load->model('Nota_model');
        $this->load->model('Kasir_model');
        $this->load->model('Stok_model');

        $id_transaksi =  $this->uri->segment('4');
        $datetime =  time();
        $pembayaran =  $this->uri->segment('6');
        $sPengerjaan = $this->uri->segment('7');

        $data['transaksi'] = $this->Kasir_model->getTransaksiByID($id_transaksi);
        $data['items'] = $this->Nota_model->getDetailTransaksiById($id_transaksi);

        if ($sPengerjaan == 1) {
            if ($data['transaksi']['stasus_pengerjaan'] == 4) {
                $sPengerjaanU = 5;
                foreach ($data['items'] as $items) {

                    $id_stok = $items['id_barang'];
                    $upstok['stokdt'] = $this->Stok_model->getStokByID($id_stok);

                    $pengurangan_stok = $upstok['stokdt']['stok_barang'] - $items['quantity'];
                    $this->Stok_model->updateStok($id_stok, $pengurangan_stok);
                }
            } else {
                $sPengerjaanU = 4;
            }
        } elseif ($sPengerjaan == 0) {
            $sPengerjaanU = 6;
        }

        $this->Nota_model->logPengerjaan($id_transaksi,  $datetime, $pembayaran, $sPengerjaanU);

        if ($sPengerjaan == 1) {
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        ' . $data['transaksi']['nama_pelanggan'] . ' pengerjaan sudah selesai</div>');
            redirect('admin/teknisi/daftarServisan');
        } elseif ($sPengerjaan == 0) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        ' . $data['transaksi']['nama_pelanggan'] . ' pengerjaan sudah Dibatalkan</div>');
            redirect('admin/teknisi/daftarServisan');
        }
    }

    public function ubahKerusakan($id_transaksi)
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Kasir_model');
        $this->load->model('Stok_model');
        $this->load->model('Nota_model');
        $id_user = $data['user']['id'];
        $data['tipe_penjualan'] = 1;

        $data['transaksi'] = $this->Kasir_model->getTransaksiByID($id_transaksi);
        $data['tittle'] = "Ubah Kerusakan " . $data['transaksi']['nama_pelanggan'];

        $data['product'] = $this->Kasir_model->getProduct();
        $data['detailTransaksiCount'] = $this->Nota_model->getDetailTransaksiCount($id_transaksi);

        $this->form_validation->set_rules('konfirmasi', 'Konfirmasi Perubahan', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar');
            $this->load->view('admin/topbar', $data);
            $this->load->view('admin/teknisiUbahKerusakan', $data);
            $this->load->view('admin/footer');
        } else {
            $this->load->model('Nota_model');

            $data['detail_transaksi'] = $this->Nota_model->getDetailTransaksiById($id_transaksi);

            $total_barang = 0;

            foreach ($data['detail_transaksi'] as $detailTrs) {
                $total_barang = $detailTrs['quantity'] + $total_barang;
            }

            $datetime =  time();
            $pembayaran =  $data['transaksi']['status_pembayaran'];
            $sPengerjaan = $this->input->post('konfirmasi');

            $this->Nota_model->logPengerjaan($id_transaksi,  $datetime, $pembayaran, $sPengerjaan);

            $data['items'] = $this->Nota_model->getDetailTransaksiById($id_transaksi);
            $total_transaksi = 0;
            foreach ($data['items'] as $items) {
                $total_transaksi = $items['total_harga'] + $total_transaksi;
            }
            $data = [
                "total_barang"  => $total_barang,
                "total"         => $total_transaksi,
                "grand_total"   => $total_transaksi
            ];
            $this->db->where('id_transaksi', $id_transaksi);
            $this->db->update('transaksi', $data);
            $namaPelanggan = $data['transaksi']['nama_pelanggan'];
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            ' . $namaPelanggan . ' Sudah Diteruskan Untuk Konfirmasi</div>');
            redirect('admin/teknisi/menungguKonfirmasi');
        }
    }

    public function tambahKerusakan($id_transaksi)
    {
        $this->load->model('Nota_model');

        $total_harga = $_POST['product_price'] * $_POST['qty'];
        $data = array(
            "id_transakasi"     => $id_transaksi,
            "id"                => '',
            "id_barang"         => $_POST["product_id"],
            "harga"             => $_POST["product_price"],
            "quantity"          => $_POST["qty"],
            "total_harga"       => $total_harga,
            "tanggal_transaksi" => time()
        );
        $this->db->insert('transaksi_detail', $data);
        echo $this->tampilIsiKerusakan($id_transaksi);
    }

    public function muatKeranjang($id_transaksi)
    {
        echo $this->tampilIsiKerusakan($id_transaksi);
    }

    public function tampilIsiKerusakan($id_transaksi)
    {
        $this->load->model('Nota_model');
        $data['items'] = $this->Nota_model->getDetailTransaksiById($id_transaksi);
        $total_transaksi = 0;
        foreach ($data['items'] as $items) {
            $total_transaksi = $items['total_harga'] + $total_transaksi;
        }
        $output = '';
        $output .= '<table class="table table-sm table-borderless">
        <thead>
            <tr>
                <th scope="col">ID&nbspBarang</th>
                <th scope="col">Nama&nbspBarang</th>
                <th scope="col">Harga</th>
                <th scope="col">Qty</th>
                <th scope="col">Sub&nbspTotal</th>
                <th scope="col">Tindakan</th>
            </tr>
        </thead>
        <tbody>';
        $count = 0;
        foreach ($data['items'] as $items) {
            $count++;
            $output .= '<tr>
            <td>' . $items['id_barang'] . '</td>
            <td>' . $items['nama_barang'] . '</td>
            <td>' . $items['harga'] . '</td>
            <td>' . $items['quantity'] . '</td>
            <td>' . $items['total_harga'] . '</td>
            <td align="center"><button type="button" name="remove" id="' . $items['id'] . '" class="btn btn-sm btn-danger remove hapus_itemtek" data-toggle="tooltip"><i class="fas fa-fw fa-trash-alt"></i></button></td>
        </tr>';
        }
        $output .= '</tbody>
        </table>
        <h6 class="font-weight-bold">Total ' . rupiah($total_transaksi) . '</h6>
        <input type="hidden" class="form-control ml-2 total_trstek" id="total_trstek" name="total_trstek" value="' . $total_transaksi . '">';
        if ($count == 0) {
            $output = '<h3>Kerusakan kosong</h3>';
        }
        return $output;
    }

    public function hapusItem($id_transaksi)
    {
        $this->load->library("cart");
        $id_detailtransaksi = $_POST["row_id"];
        $this->load->model('Nota_model');
        $this->Nota_model->deleteDetailTransaksiByID($id_detailtransaksi);
        echo $this->tampilIsiKerusakan($id_transaksi);
    }

    public function fetch()
    {
        $output = '';
        $query = '';
        $tipe_penjualan = 1;
        $this->load->model('Stok_model');
        if ($this->input->post('query')) {
            $query = $this->input->post('query');
        }
        $data = $this->Stok_model->getStokByTransaksiPenjualan($query, $tipe_penjualan);

        if ($data->num_rows() > 0) {
            $nmbr = 0;
            foreach ($data->result() as $row) {
                $nmbr = $nmbr + 1;
                $output .= '<div class="col-md-3 mt-3">
        <div class="card" style="width: auto;">
            <img src="' . base_url() . '/image/barang/' . $row->foto . '" class="card-img-top" alt="...">
            <div class="card-body p-1">
                <h5 class="card-title">' . $row->nama_barang . '</h5>
                <p class="card-text">Stok<br>' . $row->stok_barang . '<br>
                    ' . rupiah($row->harga_jual) . '
                </p>
                <input type="number" name="qty" class="form-control form-control-sm qty" id="' . $row->id_barang . '" placeholder="qty">
                <button type="button" onclick="tambahKerusakan(' . $nmbr . ')" class="btn btn-sm btn-primary mt-1 btn_add' . $nmbr . '" name="btn_add" data-productname="' . $row->nama_barang . '" data-price="' . $row->harga_jual . '" data-productid="' . $row->id_barang . '"><i class="fas fa-fw fa-plus"></i> </button>
            </div>
        </div>
    </div>';
            }
        } else {
            $output .= '<h3 class="m-3">Tidak dapat ditemukan</h3>';
        }
        echo $output;
    }
}
