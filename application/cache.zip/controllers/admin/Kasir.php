<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kasir extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_log_in();
        $this->load->library("cart");
        $this->load->library("pdf");
    }

    public function penjualanBaru()
    {
        $data['tittle'] = "Penjualan Baru";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $this->load->model('Kasir_model');
        $this->load->model('Stok_model');
        $id_user = $data['user']['id'];

        $data['product'] = $this->Kasir_model->getProduct();

        $data['stok'] = $this->Stok_model->getStok();

        $data['notacount'] = $this->Kasir_model->getIDbyToday();

        $this->form_validation->set_rules('id_transaksi', 'Id Nota', 'required|trim');
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('no_hp', 'No Telfon', 'required|trim|min_length[10]|max_length[14]');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
        $this->form_validation->set_rules('product_id', 'Jenis Device', 'required|trim');
        $this->form_validation->set_rules('platform_id', 'Tipe Device', 'required|trim');
        $this->form_validation->set_rules('is_cash', 'Tipe Pembayaran', 'required|trim');
        $this->form_validation->set_rules('uang_cash', 'Tunai', 'required|trim');
        $this->form_validation->set_rules('kembalian', 'Tunai', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar');
            $this->load->view('admin/topbar', $data);
            $this->load->view('admin/kasirPenjualan', $data);
            $this->load->view('admin/footer');
        } else {
            if ($this->input->post('id_member') == '') {
                $dtm = $this->input->post('tanggal_transaksi');
                $id_pelanggan = $dtm + 123;
                $is_member = 0;
                $this->Kasir_model->inputPelanggan($id_pelanggan, $is_member);
            } else {
                $id_pelanggan = $this->input->post('id_member');
                $is_member = 1;
                // jika sudah member tidak input data
            }

            $total_barang = 0;
            foreach ($this->cart->contents() as $items) {
                $total_barang = $total_barang + $items['qty'];
            }

            $total_transaksi = $this->cart->total();
            if ($this->input->post('submit') == 0) {
                // $sPembayaran = 1;
                $sPengerjaan = 1;
                $tanggal_diambil = 0;

                $nominal_kembalian = $this->input->post('kembalian');
                $grand_total = $this->input->post('totalpdiskon');
                $nominal = $grand_total + ($nominal_kembalian);
                if ($nominal > 0 && $nominal < $grand_total) {
                    // dp
                    $sPembayaran = 2;
                } elseif ($nominal > $grand_total || $nominal_kembalian == 0) {
                    // tidak
                    $sPembayaran = 99;
                } elseif ($nominal == 0) {
                    // tidak
                    $sPembayaran = 1;
                } elseif ($nominal <= $grand_total) {
                    // tidak
                    $sPembayaran = 1;
                }
            } else {
                $sPembayaran = 99;
                $sPengerjaan = 99;
                $tanggal_diambil = $this->input->post('tanggal_transaksi', true);
            }

            $this->Kasir_model->tambahTransaksi(
                $total_barang,
                $total_transaksi,
                $id_pelanggan,
                $id_user,
                $sPembayaran,
                $sPengerjaan,
                $tanggal_diambil
            );

            $this->Kasir_model->logTransaksi($sPembayaran, $sPengerjaan);

            foreach ($this->cart->contents() as $items) {
                $data = [
                    "id" => '',
                    "id_transakasi" => $this->input->post('id_transaksi', true),
                    "id_barang" => $items['id'],
                    "quantity" => $items['qty'],
                    "harga" => $items['price'],
                    "total_harga" => $items['subtotal'],
                    "tanggal_transaksi" => $this->input->post('tanggal_transaksi', true)
                ];
                $this->db->insert('transaksi_detail', $data);

                $id_stok = $items['id'];
                $upstok['stokdt'] = $this->Stok_model->getStokByID($id_stok);

                $pengurangan_stok = $upstok['stokdt']['stok_barang'] - $items['qty'];

                if ($this->input->post('submit') == 0) {
                } else {
                    $this->Stok_model->updateStok($id_stok, $pengurangan_stok);
                }
            }

            if ($this->input->post('submit') == 0) {
                $this->cart->destroy();
                redirect('admin/kasir/cetakNota/' . $this->input->post('id_transaksi', true));
            } elseif ($this->input->post('submit') == 1) {
                $this->cart->destroy();
                redirect('admin/kasir/cetakNota/' . $this->input->post('id_transaksi', true));
            }
        }
    }

    // dropdown berantai
    public function platformSelect()
    {
        // Ambil data id_gawai yang dikirim via ajax post
        $product_id = $this->input->post('product_id');

        $this->load->model('Product_model');
        $tipe_gawai = $this->Product_model->getProductbyId($product_id);

        // Buat variabel untuk menampung tag-tag option nya
        // Set defaultnya dengan tag option Pilih
        $lists = "<option value=''>Select Platform</option>";

        foreach ($tipe_gawai as $data) {
            $lists .= "<option value='" . $data['id'] . "'>" . $data['platform'] . "</option>"; // Tambahkan tag option ke variabel $lists
        }

        $callback = array('platform_id' => $lists); // Masukan variabel lists tadi ke dalam array $callback dengan index array : list_kota
        echo json_encode($callback); // konversi varibael $callback menjadi JSON
    }


    public function tambahKeranjang()
    {
        $this->load->library("cart");
        $data = array(
            "id" => $_POST["product_id"],
            "name" => $_POST["product_name"],
            "price" => $_POST["product_price"],
            "qty" => $_POST["qty"]
        );
        $this->cart->insert($data);
        echo $this->tampilIsiKeranjang();
    }

    public function muatKeranjang()
    {
        echo $this->tampilIsiKeranjang();
    }

    public function tampilIsiKeranjang()
    {
        $this->load->library("cart");
        $total_transaksi = $this->cart->total();
        $output = '';
        $output .= '<table class="table table-sm table-borderless">
        <thead>
            <tr>
                <th scope="col">Id&nbspBarang</th>
                <th scope="col">Nama&nbspBarang</th>
                <th scope="col">Harga</th>
                <th scope="col">Qty</th>
                <th scope="col">Sub&nbspTotal</th>
                <th scope="col">Tindakan</th>
            </tr>
        </thead>
        <tbody>';
        $count = 0;
        foreach ($this->cart->contents() as $items) {
            $count++;
            $output .= '<tr>
            <td>' . $items['id'] . '</td>
            <td>' . $items['name'] . '</td>
            <td>' . $items['price'] . '</td>
            <td>' . $items['qty'] . '</td>
            <td>' . $items['subtotal'] . '</td>
            <td align="center"><button type="button" name="remove" id="' . $items['rowid'] . '" class="btn btn-sm btn-danger remove hapus_item" data-toggle="tooltip"><i class="fas fa-fw fa-trash-alt"></i></button></td>
        </tr>';
        }
        $output .= '</tbody>
        </table>
        <h6 class="font-weight-bold">Total ' . rupiah($total_transaksi) . '</h6>
        <input type="hidden" class="form-control ml-2 total_trs" id="total_trs" name="total_trs" value="' . $total_transaksi . '">';
        if ($count == 0) {
            $output = '<h3>Keranjang kosong</h3>';
        }
        return $output;
    }

    public function hapusItem()
    {
        $this->load->library("cart");
        $row_id = $_POST["row_id"];
        $data = array(
            'rowid'     => $row_id,
            'qty'       => 0
        );
        $this->cart->update($data);
        echo $this->tampilIsiKeranjang();
    }

    public function ubahBayar($id_transaksi)
    {
        echo $this->tampilIsiKerusakan($id_transaksi);
    }

    public function tampilIsiKerusakan($id_transaksi)
    {
        $this->load->model('Nota_model');
        $data['items'] = $this->Nota_model->getDetailTransaksiById($id_transaksi);
        $total_transaksi = 0;
        foreach ($data['items'] as $items) {
            $total_transaksi = $items['total_harga'] + $total_transaksi;
        }
        $output = '';
        $output .= '<table class="table table-sm table-borderless">
        <thead>
            <tr>
                <th scope="col">ID&nbspBarang</th>
                <th scope="col">Nama&nbspBarang</th>
                <th scope="col">Harga</th>
                <th scope="col">Qty</th>
                <th scope="col">Sub&nbspTotal</th>
                <th scope="col">Tindakan</th>
            </tr>
        </thead>
        <tbody>';
        $count = 0;
        foreach ($data['items'] as $items) {
            $count++;
            $output .= '<tr>
            <td>' . $items['id_barang'] . '</td>
            <td>' . $items['nama_barang'] . '</td>
            <td>' . $items['harga'] . '</td>
            <td>' . $items['quantity'] . '</td>
            <td>' . $items['total_harga'] . '</td>
        </tr>';
        }
        $output .= '</tbody>
        </table>
        <h6 class="font-weight-bold">Total ' . rupiah($total_transaksi) . '</h6>
        <input type="hidden" class="form-control ml-2 total_trs" id="total_trs" name="total_trs" value="' . $total_transaksi . '">';
        if ($count == 0) {
            $output = '<h3>Kerusakan kosong</h3>';
        }
        return $output;
    }

    public function fetch()
    {
        $output = '';
        $query = '';
        $this->load->model('Kasir_model');
        if ($this->input->post('query')) {
            $query = $this->input->post('query');
        }
        $data = $this->Kasir_model->fetch($query);

        if ($data->num_rows() > 0) {
            $nmbr = 0;
            foreach ($data->result() as $row) {
                $nmbr = $nmbr + 1;
                $output .= '<div class="col-md-3 mt-3">
        <div class="card" style="width: auto;">
            <img src="' . base_url() . '/image/barang/' . $row->foto . '" class="card-img-top" alt="...">
            <div class="card-body p-1">
                <h5 class="card-title">' . $row->nama_barang . '</h5>
                <p class="card-text">Stok<br>' . $row->stok_barang . '<br>
                    ' . rupiah($row->harga_jual) . '
                </p>
                <input type="number" name="qty" class="form-control form-control-sm qty" id="' . $row->id_barang . '" placeholder="qty">
                <button type="button" onclick="tambahKeranjang(' . $nmbr . ')" class="btn btn-sm btn-primary mt-1 btn_add' . $nmbr . '" name="btn_add" data-productname="' . $row->nama_barang . '" data-price="' . $row->harga_jual . '" data-productid="' . $row->id_barang . '"><i class="fas fa-fw fa-plus"></i> </button>
            </div>
        </div>
    </div>';
            }
        } else {
            $output .= '<h3 class="m-3">Tidak dapat ditemukan</h3>';
        }
        echo $output;
    }

    public function belumDiambil()
    {
        $data['tittle'] = "Belum Diambil";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->notaBelumDiambil();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/notaList', $data);
        $this->load->view('admin/footer');
    }

    public function notaDiambil()
    {
        $data['tittle'] = "Nota Diambil";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->notaDiambil();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/notaList', $data);
        $this->load->view('admin/footer');
    }


    public function Bayar($id_transaksi)
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Kasir_model');
        $this->load->model('Stok_model');
        $this->load->model('Nota_model');
        $id_user = $data['user']['id'];
        $data['tipe_penjualan'] = 1;

        $data['transaksi'] = $this->Kasir_model->getTransaksiByID($id_transaksi);
        $data['tittle'] = "Ubah Kerusakan " . $data['transaksi']['nama_pelanggan'];

        $data['product'] = $this->Kasir_model->getProduct();
        $data['detailTransaksiCount'] = $this->Nota_model->getDetailTransaksiCount($id_transaksi);

        $this->form_validation->set_rules('diskon', 'Tipe Pembayaran', 'required|trim');
        $this->form_validation->set_rules('is_cash', 'Tipe Pembayaran', 'required|trim');
        $this->form_validation->set_rules('uang_cash', 'Tunai', 'required|trim');
        $this->form_validation->set_rules('kembalian', 'Tunai', 'required|trim');
        $this->form_validation->set_rules('discnom', 'Tipe diskon', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('admin/header', $data);
            $this->load->view('admin/sidebar');
            $this->load->view('admin/topbar', $data);
            $this->load->view('admin/kasirUbahPembayaran', $data);
            $this->load->view('admin/footer');
        } else {

            $datetime = time();
            if ($this->input->post('submit') == 0) {
                $sPembayaran = 2;
                $sPengerjaan = $data['transaksi']['stasus_pengerjaan'];
                $tanggal_diambil = 0;
            } elseif ($this->input->post('submit') == 1) {
                if ($data['transaksi']['stasus_pengerjaan'] == 6) {
                    $sPembayaran = 3;
                    $sPengerjaan = 99;
                    $tanggal_diambil = $datetime;
                } elseif ($data['transaksi']['stasus_pengerjaan'] == 5) {
                    $sPembayaran = 99;
                    $sPengerjaan = 99;
                    $tanggal_diambil = $datetime;
                }
            }

            $updatedt = [
                "diskon"                => $this->input->post('diskon', true),
                "disc_status"           => $this->input->post('discnom', true),
                "is_cash"               => $this->input->post('is_cash'),
                "cash"                  => $this->input->post('uang_cash', true),
                "change_nominal"        => $this->input->post('kembalian', true),
                "total"                 => $this->input->post('total_trs', true),
                "grand_total"           => $this->input->post('totalpdiskon', true),
                "tanggal_diambil"       => $tanggal_diambil,
                "status_pembayaran"     => $sPembayaran,
                "stasus_pengerjaan"     => $sPengerjaan
            ];

            $this->Kasir_model->logPembayaran($id_transaksi,  $datetime, $sPembayaran, $sPengerjaan);

            $this->Kasir_model->updatePembayaran($id_transaksi, $updatedt);
            if ($this->input->post('submit') == 0) {
                redirect('admin/kasir/belumDiambil');
            } elseif ($this->input->post('submit') == 1) {
                if ($data['transaksi']['stasus_pengerjaan'] == 6) {
                    redirect('admin/kasir/belumDiambil/');
                } elseif ($data['transaksi']['stasus_pengerjaan'] == 5) {
                    redirect('admin/kasir/cetakNota/' . $this->input->post('id_transaksi', true));
                }
            }
        }
    }

    public function cetakNota($id_Transaksi)
    {
        $data['tittle'] = "Belum Diambil";
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->getNotaByID($id_Transaksi);
        $data['item'] = $this->Nota_model->getDetailTransaksiById($id_Transaksi);
        $this->load->view('admin/cetakNota', $data);
    }
}
