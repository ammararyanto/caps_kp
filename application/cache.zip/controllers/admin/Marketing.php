<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Marketing extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_log_in();
    }

    public function index()
    {
        $data['tittle'] = "Marketing";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Nota_model');
        $data['menungguKonfirmasi'] = $this->Nota_model->servisBelumDikerjakanCount(2);
        $data['belumDiambil'] = $this->Nota_model->notaBelumDiambilCount();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/marketing', $data);
        $this->load->view('admin/footer');
    }

    public function harusKonfirmasi()
    {
        $data['tittle'] = "Harus di Konfirmasi";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['sPengerjaan'] = 2;
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->servisBelumDikerjakan($data['sPengerjaan']);

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/marketingPerluKonfirmasi', $data);
        $this->load->view('admin/footer');
    }

    public function belumDiambil()
    {
        $data['tittle'] = "Harus di Konfirmasi";
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['sPengerjaan'] = 99;
        $this->load->model('Nota_model');
        $data['nota'] = $this->Nota_model->notaCancelDone();

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/marketingPerluKonfirmasi', $data);
        $this->load->view('admin/footer');
    }


    public function lihatDetail($id_kerusakan)
    {
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Nota_model');
        $data['transaksi'] = $this->Nota_model->getNotaByID($id_kerusakan);
        $data['detail'] = $this->Nota_model->getDetailTransaksiById($id_kerusakan);

        $data['tittle'] = "Kerusakan " . $data['transaksi']['nama_pelanggan'];

        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/topbar', $data);
        $this->load->view('admin/marketingDetailKeruskan', $data);
        $this->load->view('admin/footer');
    }


    public function konfirmasi($id_transaksi)
    {
        $this->load->model('Nota_model');
        $data['transaksi'] = $this->Nota_model->getNotaByID($id_transaksi);

        $datetime =  time();
        $pembayaran =  $data['transaksi']['status_pembayaran'];
        $sPengerjaan = 3;

        $this->Nota_model->logPengerjaan($id_transaksi,  $datetime, $pembayaran, $sPengerjaan);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            ' . $data['transaksi']['nama_pelanggan'] . ' Sudah Diteruskan Untuk Dikerjakan</div>');
        redirect('admin/marketing/harusKonfirmasi');
    }
}
